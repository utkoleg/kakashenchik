package client;

import javax.swing.*;

public class DeletePage extends JPanel {
    private Mainframe mainframe;

    public DeletePage(Mainframe mainframe, ServerConnector sc){
        this.mainframe = mainframe;
        setSize(500, 500);
        setLayout(null);
    }
}
