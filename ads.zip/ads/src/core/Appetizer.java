package core;

public class Appetizer extends Item {
    private final String type = "apperizer";
    public Appetizer() {
    }

    public Appetizer(String name, String description, int price) {
        super(name, description, price);
    }
}
