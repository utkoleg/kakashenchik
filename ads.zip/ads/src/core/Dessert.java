package core;

public class Dessert extends Item {
    private final String type = "dessert";
    public Dessert() {
    }

    public Dessert(String name, String description, int price) {
        super(name, description, price);
    }
}
