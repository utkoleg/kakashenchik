package core;

public class Entree extends Item {
    private final String type = "entree";

    public Entree() {
    }

    public Entree(String name, String description, int price) {
        super(name, description, price);
    }
}
