package core;

public class Drink extends Item {
    private final String type = "drink";
    public Drink() {
    }

    public Drink(String name, String description, int price) {
        super(name, description, price);
    }
}
