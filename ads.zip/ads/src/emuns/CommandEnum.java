package emuns;

public enum CommandEnum {
    ADD,
    LIST,
    DELETE,
    EXIT
}
